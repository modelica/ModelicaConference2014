/***************************************************************************************************
* Author: 
*        Victorino Sanz 
*        Dpto. Informática y Automática, UNED
*        Juan del Rosal, 16
*        28040, Madrid
*        Spain
*        Email: vsanz@dia.uned.es
*
* Licensed by Victorino Sanz under the LGPL License
* Copyright © 2013, Victorino Sanz.
* 
****************************************************************************************************/

#ifndef WOLFRAM
#define WOLFRAM

#include <CellularAutomataLib.c>

/****************************************/
/* WOLFRAM RULES CELLULAR AUTOMATA      */
/****************************************/

typedef struct RState{
    int v;
}RState;


void * RDefaultState(){
    RState *s;
    s = (RState *)malloc(sizeof(RState));

    s->v = 0;
    return (void *)s;
}

int RCreate(int ncols, int *neighborhood, size_t n1, int n_inputs, int wrapped_borders, int plot_animation,int plot_range,int displayDelay,int plot_history, const char *path, const char *name){
    void* (*defaultState)() = &RDefaultState;
    ModelicaFormatMessage("NAME = %s\n",name);
    return CS1D_Create(ncols, neighborhood, n1, n_inputs, wrapped_borders,plot_animation,plot_range,displayDelay,plot_history,path,name, defaultState);
}

void RInitialState(void *cell){
    RState *s;
    s= (RState *)cell;
    s->v = 1;
    return;
}

// initializing function for the selected cell
void RInitial(int space, int col){
    void  (*initialState)(void *) = &RInitialState;
    CS1D_Init(space, col, initialState);
    return;
}

// RULE FUNCTIONS

void* rule110(void* cellstate, void** neighbors, int n_neighbors,int *neighbors_present,void** inputs, int n_inputs, int *inputs_rcv){

  int n0,n1;
  RState *out;
  RState *cs;
  RState **ne;
  RState **in;

  cs = (RState *)cellstate;
  ne = (RState **)neighbors;
  in = (RState **)inputs;
  out =(RState *)malloc(sizeof(RState));

  if (neighbors_present[0] && ne[0]->v > 0)
      n0 = 1;
  else
      n0 = 0;

  if (neighbors_present[1] && ne[1]->v > 0)
      n1 = 1;
  else
      n1 = 0;
  
  
  if(      n0 == 1 && cs->v == 1 && n1 == 1){
      out->v = 0;
  }else if(n0 == 1 && cs->v == 1 && n1 == 0){
    out->v = 1;
  }else if(n0 == 1 && cs->v == 0 && n1 == 1){
    out->v = 1;
  }else if(n0 == 1 && cs->v == 0 && n1 == 0){
    out->v = 0;
  }else if(n0 == 0 && cs->v == 1 && n1 == 1){
    out->v = 1;
  }else if(n0 == 0 && cs->v == 1 && n1 == 0){
    out->v = 1;
  }else if(n0 == 0 && cs->v == 0 && n1 == 1){
    out->v = 1;
  }else if(n0 == 0 && cs->v == 0 && n1 == 0){
    out->v = 0;
  }
  
  //printf("%f,%f,%f = %f\n",n0,cellstate,n1,out);
  
  return (void *)out;
}

// Function that returns the value to display in the graphical animation
double RDisplay(void *cell){
    RState *s;

    s = (RState *)cell;
    return (double)s->v;
}


int R110Step(int space){
    void* (*rule)(void*,void**,int,int*,void**,int,int*) = &rule110;
    double (*display)(void*) = &RDisplay;
    
    CS1D_Step(space,rule,display);
    return 1;
}

/*************************************************************************/

void* rule30(void* cellstate, void**neighbors, int n_neighbors, int *neighbors_present, void**inputs, int n_inputs, int *inputs_rcv){

  int n0,n1;
  RState *out;
  RState *cs;
  RState **ne;
  RState **in;

  cs = (RState *)cellstate;
  ne = (RState **)neighbors;
  in = (RState **)inputs;
  out =(RState *)malloc(sizeof(RState));

  if (neighbors_present[0] && ne[0]->v > 0)
      n0 = 1;
  else
      n0 = 0;

  if (neighbors_present[1] && ne[1]->v > 0)
      n1 = 1;
  else
      n1 = 0;
  
  if(      n0 == 1 && cs->v == 1 && n1 == 1){
    out->v = 0;
  }else if(n0 == 1 && cs->v == 1 && n1 == 0){
    out->v = 0;
  }else if(n0 == 1 && cs->v == 0 && n1 == 1){
    out->v = 0;
  }else if(n0 == 1 && cs->v == 0 && n1 == 0){
    out->v = 1;
  }else if(n0 == 0 && cs->v == 1 && n1 == 1){
    out->v = 1;
  }else if(n0 == 0 && cs->v == 1 && n1 == 0){
    out->v = 1;
  }else if(n0 == 0 && cs->v == 0 && n1 == 1){
    out->v = 1;
  }else if(n0 == 0 && cs->v == 0 && n1 == 0){
    out->v = 0;
  }
  
  if ((inputs != NULL) && (inputs_rcv[0] > 0))
      out->v = in[0]->v;
  
  return out;
}

int R30Step(int space){
    void* (*rule)(void*,void**,int,int*,void**,int,int*) = &rule30;
    double (*display)(void*) = &RDisplay;
    
    CS1D_Step(space,rule,display);
    return 1;
}



void RSetInput(int Fspace, int Frow, int Fcol, int Tspace, int Trow, int Tcol, int input_id){
    RState* s;
    RState* inp;
    
    inp = (RState *)malloc(sizeof(RState));
    s = (RState *)CS1D_Get(Fspace,Fcol);
    *inp = *s;
    CS1D_SetInput(Tspace,Tcol,(void*)inp,input_id);
    return;
}


#endif
