/**********************************************************
* Author: 
*        Victorino Sanz 
*        Dpto. Informática y Automática, UNED
*        Juan del Rosal, 16
*        28040, Madrid
*        Spain
*        Email: vsanz@dia.uned.es
*
* Licensed by Victorino Sanz under the Modelica License 2
* Copyright © 2013, Victorino Sanz.
* 
************************************************************/

#ifndef CELLULARAUTOMATA
#define CELLULARAUTOMATA

#ifdef _WIN32
      #include <windows.h>
#endif

/*****************************************/
/* 1D CELLULAR AUTOMATA                  */
/*****************************************/


/* Object data type */
typedef struct Cell1D{
    void* cellstate;
    int pos;
    struct Cell1D **neighbors;
    int *neighbors_present;
    void** inputs;
    int *inputs_rcv;
    int update;
} Cell1D;

typedef struct CellSpace1D{
    Cell1D *M;
    double **hist;
    int n_hist;
    int ncols;
    int displayDelay;
    int *neighborhood;
    int n_neighbors;
    int n_inputs;
    int plot_history;
    int plot_animation;
    int wrapped_borders; // 0 none, 1 yes
    FILE * gp;
}CellSpace1D;



int mod (int a, int b){
  int ret;
  
  if(b < 0) //you can check for b == 0 separately and do what you want
    return mod(-a, -b);   
  ret = a % b;
  if(ret < 0)
    ret+=b;
  return ret;
}

/* ###################################################*/

int CS1D_Create(int ncols, int *neighborhood, size_t n1, int n_inputs, int wrapped_borders, int plot_animation,int plot_range,int displayDelay,int plot_history, const char *path, const char *name, void* (*defaultState)()){
    int i,k;
    CellSpace1D *s;
    
    s = (CellSpace1D *)malloc(sizeof(CellSpace1D));
    s->M = (Cell1D *)malloc(ncols*sizeof(Cell1D));
    s->ncols = ncols;
    s->plot_history = plot_history;
    s->hist = NULL;
    s->n_hist = 0;
    s->n_neighbors = n1;
    s->n_inputs = n_inputs;
    s->neighborhood = (int *)malloc(sizeof(int)*n1);
    for(i=0;i<n1;i++){
        s->neighborhood[i] = neighborhood[i];
    }
    s->plot_animation = plot_animation;
    s->wrapped_borders = wrapped_borders;
    s->displayDelay = displayDelay;
    for(i=0;i<ncols;i++){
        s->M[i].cellstate = defaultState(); // user defined default state
        s->M[i].pos = i;
        s->M[i].update = 0;
        if (n_inputs > 0){
            s->M[i].inputs = (void**)malloc(sizeof(void*)*n_inputs);
            s->M[i].inputs_rcv = (int *)malloc(sizeof(int)*n_inputs);
            for(k=0;k<n_inputs;k++){
                s->M[i].inputs[k] = NULL;
                s->M[i].inputs_rcv[k] = 0;
            }
        }else{
            s->M[i].inputs = NULL;
            s->M[i].inputs_rcv = NULL;
        }
        s->M[i].neighbors = (Cell1D **)malloc(sizeof(Cell1D *)*n1);
        s->M[i].neighbors_present = (int *)malloc(sizeof(int)*n1);
        for(k=0;k<n1;k++){
            // check for wrapped boundaries, setting neighbors_rcv to 0 when neighbor should not be used.
            if ((s->neighborhood[k]+i < 0 || s->neighborhood[k]+i > ncols-1) && !wrapped_borders) {
                s->M[i].neighbors_present[k] = 0; // neighbor not present, outside row border and not wrapped
            }else{ // neighbor present
                s->M[i].neighbors_present[k] = 1;
                s->M[i].neighbors[k] = &(s->M[mod(s->neighborhood[k]+i,ncols)]);
            }
            
        }
    }
    
    if(plot_animation){
#ifdef _WIN32
        s->gp = _popen(path, "w");
#else
        s->gp = popen(path, "w");
#endif
        
        if(s->gp == NULL){
            fprintf(stderr, "Oops, I can't find %s.", path);
            exit(EXIT_FAILURE);
        }    
#ifdef _WIN32
        fprintf(s->gp, "set terminal wxt persist\n");
#else
        fprintf(s->gp, "set terminal x11 \n");
#endif
        fprintf(s->gp, "set title \"%s\" \n",name);
        fprintf(s->gp, "set yrange [%d:0] \n",2*ncols);
        if (plot_history)
            fprintf(s->gp, "set autoscale xy \n");
        fprintf(s->gp, "set cbrange [0:%d] \n",plot_range);
    }   
    return (int)s;
    
}


int CS1D_Delete(int space){
    CellSpace1D *s;
    char c;

    s = (CellSpace1D *)space;
    free(s->M);
    free(s->hist);
    s->ncols = 0;
    free(s->neighborhood);
#ifdef _WIN32
    fprintf(s->gp, "pause mouse\n");
    //    ModelicaFormatMessage("Press any key to terminate (plot will close after pressing)...\n");
    //c = (char)getchar();
    _pclose(s->gp);
#else
    pclose(s->gp);
#endif
    //fclose(s->gp);
    free(s);
    return 1;
}


void CS1D_Init(int space, int pos,void (*initialState)(void*)){
    int i,j;
    CellSpace1D *s;
    
    s = (CellSpace1D *)space;
    initialState(s->M[pos-1].cellstate);
    s->M[pos-1].update = 1;
    
    // update neighbors
    for(i=0;i<s->n_neighbors;i++)
        if (s->M[pos-1].neighbors_present[i])
            s->M[pos-1].neighbors[i]->update = 1;

    
    return;
}

void CS1D_Set(int space, int pos, double value){ // SETS CELL STATE
    int i;
    CellSpace1D *s;
    
    s = (CellSpace1D *)space;
    s->M[pos-1].cellstate = (void*)&value;
    s->M[pos-1].update = 1;

    // update neighbors
    for(i=0;i<s->n_neighbors;i++)
        if (s->M[pos-1].neighbors_present[i])
            s->M[pos-1].neighbors[i]->update = 1;
    
    return;
}


void CS1D_SetInput(int space, int pos, void* value, int input_id){ // SETS CELL INPUT
  CellSpace1D *s;
  
  s = (CellSpace1D *)space;
  if (s->M[pos-1].inputs[input_id-1] != NULL) // free previous input
      free(s->M[pos-1].inputs[input_id-1]);
  s->M[pos-1].inputs[input_id-1] = value;
  s->M[pos-1].inputs_rcv[input_id-1] = 1;
  s->M[pos-1].update = 1;
  
  return;
}


void* CS1D_Get(int space, int pos){
    CellSpace1D *s;
    
    s = (CellSpace1D *)space;
    return s->M[pos-1].cellstate;
}



int CS1D_Size(int space){
  CellSpace1D *s;

  s = (CellSpace1D *)space;
  return s->ncols;
}


void CS1D_Step(int space, void* (*rule)(void*,void**,int,int*,void**,int,int*),double (*display)(void*)){
  void** new;
  int i,j,k;
  CellSpace1D *s;
  void*** aux;
  void** neighbors;
  
  s = (CellSpace1D *)space;

  
  
  // Store state and print current history
  if(s->plot_animation){
      fprintf(s->gp,"plot \'-\' matrix with image\n");
      if (s->plot_history){
          s->n_hist++;
          s->hist = (double**)realloc((double**)s->hist,sizeof(double*)*s->n_hist);
          s->hist[s->n_hist-1] = (double*)malloc(sizeof(double)*s->ncols);
          if (s->hist == NULL){
              //ModelicaFormatMessage("realloc failed!\n!");
              exit(-1);
          }
          
          for (i=0;i<s->ncols;i++){
              s->hist[s->n_hist-1][i] = display(s->M[i].cellstate);
          }
          // print history
          for(i=0;i<s->n_hist;i++){
              for(j=0;j<s->ncols;j++){
                  fprintf(s->gp,"%f ",s->hist[i][j]);
                  //printf("%d ",s->hist[i][j]);
              }
              fprintf(s->gp,"\n");
              //printf("\n");
          }
      } else{ // NO HISTORY, print first emtpy row to avoid gnuplot problem (min matrix plot of size 2x2)
          for(j=0;j<s->ncols;j++){
              fprintf(s->gp,"0 ");
              //printf("%d ",s->hist[i][j]);
          }       
          fprintf(s->gp,"\n");
      }
  }
  
  // dynamic memory for neighbors
  neighbors = (void**)malloc(sizeof(void*)*s->n_neighbors);
  
  // calculate and print new cellstates
  new = (void**)malloc(sizeof(void*)*s->ncols);  
  for(i=0;i<s->ncols;i++){
      if(s->M[i].update){
          // join neighbor states
	  for(k=0;k<s->n_neighbors;k++)
              if (s->M[i].neighbors_present[k]){
                  neighbors[k] = s->M[i].neighbors[k]->cellstate;
              }
          new[i] = rule(s->M[i].cellstate,neighbors,s->n_neighbors,s->M[i].neighbors_present,s->M[i].inputs,s->n_inputs,s->M[i].inputs_rcv);
          for (k=0;k<s->n_inputs;k++){
	      free(s->M[i].inputs[k]);
	      s->M[i].inputs[k] = NULL;
	      s->M[i].inputs_rcv[k] = 0;
	  }
          s->M[i].update = 0; // reset update flag
	  if(s->plot_animation)
	      fprintf(s->gp,"%f ",display(new[i]));
          //printf("%f ",CellState1D2float(new[i]));
      }else{
          new[i] = NULL;
	  if(s->plot_animation)
	      fprintf(s->gp,"%f ",display(s->M[i].cellstate));
      }
  }
  if(s->plot_animation){
      fprintf(s->gp,"\n");
      fprintf(s->gp,"\n");
      fprintf(s->gp,"e\n");
      //printf("\n");
      //printf("\n");
      //printf("e\n");
#ifdef _WIN32
      Sleep(s->displayDelay/1000);
#else
      usleep(s->displayDelay);
#endif
      fflush(s->gp);
  }
  
  // update cellstates
  for(i=0;i<s->ncols;i++){
      if(new[i] != NULL){
	  free(s->M[i].cellstate);
          s->M[i].cellstate = new[i];
	  new[i] = NULL;
          // update neighbors
          for(k=0;k<s->n_neighbors;k++)
              if (s->M[i].neighbors_present[k])
                  s->M[i].neighbors[k]->update = 1;
          s->M[i].update = 1;
      }
  }
  free(new);
  free(neighbors);
  return;
}

void CS1D_NSteps(int N,int space, void * (*rule)(void*,void**,int,int *,void**,int,int*),double (*display)(void*)){
    int i;
    
    for (i=0;i<N;i++)
	CS1D_Step(space,rule,display);
    
    return;
    
}

      
 
// ****************************************************
// 2D CELLULAR AUTOMATA
// ****************************************************


/* data type */

typedef struct Cell2D{
    void* cellstate; // pointer to user-defined state
    int row;
    int col;
    struct Cell2D **neighbors;
    int *neighbors_present;
    void** inputs;
    int *inputs_rcv;
    int update;
} Cell2D;

typedef struct CellSpace2D{
    Cell2D **M;
    int ncols;
    int nrows;
    int displayDelay;
    int **neighborhood;
    int n_neighbors;
    int n_inputs;
    int plot_animation; // 0 false, 1 true
    int wrapped_borders; // 0 none, 1 north-south, 2 east-west, 3 all
    FILE * gp;
}CellSpace2D;


/* ###################################################*/

int CS2D_Create(int nrows, int ncols, int *neighborhood, size_t n1, size_t n2, int n_inputs, int wrapped_borders,int plot_animation,int plot_range,int displayDelay, const char *path,const char *name, void* (*defaultState)()){
    CellSpace2D *s;
    int i,j,k;
    
    s = (CellSpace2D *)malloc(sizeof(CellSpace2D));
    s->M = (Cell2D **)malloc(nrows*sizeof(Cell2D*));    
    for(i=0;i<nrows;i++)
        s->M[i] = (Cell2D *)malloc(ncols*sizeof(Cell2D));
    s->ncols = ncols;
    s->nrows = nrows;
    s->n_neighbors = n1;
    s->n_inputs = n_inputs;
    s->neighborhood = (int **)malloc(sizeof(int *)*n1);
    for(i=0;i<n1;i++)
        s->neighborhood[i] = (int *)malloc(sizeof(int)*n2);
    j = 0;
    for(i=0;i<n1*n2;i+=2){
        s->neighborhood[j][0] = neighborhood[i];
        s->neighborhood[j][1] = neighborhood[i+1];
        j++;
    }
    s->plot_animation = plot_animation;
    s->wrapped_borders = wrapped_borders;
    s->displayDelay = displayDelay;
    for(i=0;i<nrows;i++)
        for(j=0;j<ncols;j++){
            s->M[i][j].cellstate = defaultState();
            s->M[i][j].row = i; // position in the space
            s->M[i][j].col = j;
            s->M[i][j].update = 0; // do not evaluate cells with default state
            // space for storing input values
            if (n_inputs > 0){
                s->M[i][j].inputs = (void **)malloc(sizeof(void *)*n_inputs);
                s->M[i][j].inputs_rcv = (int *)malloc(sizeof(int)*n_inputs);
                for(k=0;k<n_inputs;k++){
                    s->M[i][j].inputs[k] = NULL; //defaultState();
                    s->M[i][j].inputs_rcv[k] = 0;
                }
            }else{
                s->M[i][j].inputs = NULL;
                s->M[i][j].inputs_rcv = NULL;
            }
            // space for storing states of neighbors
            s->M[i][j].neighbors = (Cell2D **)malloc(sizeof(Cell2D *)*n1);
            s->M[i][j].neighbors_present = (int *)malloc(sizeof(int)*n1);
            for(k=0;k<n1;k++){
                // check for wrapped boundaries, setting neighbors_rcv to 0 when neighbor should not be used.
                if ((s->neighborhood[k][0]+i < 0 || s->neighborhood[k][0]+i > nrows-1) && (wrapped_borders == 0 || wrapped_borders == 2)) {
                    s->M[i][j].neighbors_present[k] = 0; // neighbor not present, outside row border and not wrapped
                }else if ((s->neighborhood[k][1]+j < 0 || s->neighborhood[k][1]+j > ncols-1) && (wrapped_borders == 0 || wrapped_borders == 1)) {
                    s->M[i][j].neighbors_present[k] = 0; // neighbor not present, outside column border and not wrapped
                }else{ // neighbor present
                    s->M[i][j].neighbors_present[k] = 1;
                    s->M[i][j].neighbors[k] = &(s->M[mod(s->neighborhood[k][0]+i,nrows)][mod(s->neighborhood[k][1]+j,ncols)]);
                }
            }
        }
    
    if (plot_animation){
#ifdef _WIN32
        s->gp = _popen(path, "w");
#else
        s->gp = popen(path, "w");
#endif
        
        if(s->gp == NULL){
            fprintf(stderr, "Oops, I can't find %s.", path);
            exit(EXIT_FAILURE);
        }    
#ifdef _WIN32
        fprintf(s->gp, "set terminal wxt persist \n");
#else
        fprintf(s->gp, "set terminal x11 \n");
#endif
        fprintf(s->gp, "set title \"%s\" \n",name);
        fprintf(s->gp, "set yrange [%d:0] \n",nrows);
        fprintf(s->gp, "set autoscale xy \n");
        fprintf(s->gp, "set cbrange [0:%d] \n",plot_range);
    }
    
    return (int)s;
}

int CS2D_Delete(int space){
  CellSpace2D *s;
  char c;
  
  s =(CellSpace2D *)space;
  free(s->M);
  s->ncols = 0;
  s->nrows = 0;
  free(s->neighborhood);
  if(s->plot_animation){
#ifdef _WIN32
    fprintf(s->gp, "pause mouse\n");
    //    ModelicaFormatMessage("Press any key to terminate (plots will close after pressing)...\n");
    //c = (char)getchar();
    _pclose(s->gp);
#else
      pclose(s->gp);
#endif
  }
  //fclose(s->gp);
  return 1;
}



void CS2D_Init(int space,int row,int col,void (*initialState)(void*)){
    int i;
    CellSpace2D *s;
    
    s = (CellSpace2D *)space;
    if (initialState != NULL)
	initialState(s->M[row-1][col-1].cellstate);
    s->M[row-1][col-1].update = 1; // evaluate cell after state changed
    //ModelicaFormatMessage("Init cell (%d) %d,%d\n",space,row,col);
    
    // update neighbors
    for(i=0;i<s->n_neighbors;i++)
        if (s->M[row-1][col-1].neighbors_present[i])
            s->M[row-1][col-1].neighbors[i]->update = 1;
    
    return;
}

void CS2D_Set(int space, int row,int col,double value){
    int i;
    CellSpace2D *s;
    
    s = (CellSpace2D *)space;
    s->M[row-1][col-1].cellstate = (void *)&value;
    s->M[row-1][col-1].update = 1; // evaluate cell after state changed
    //ModelicaFormatMessage("Set space=%d, [%d][%d] = %f\n",space,row+1,col+1,value);
    
    
    // update neighbors
    for(i=0;i<s->n_neighbors;i++)
        if (s->M[row-1][col-1].neighbors_present[i])
            s->M[row-1][col-1].neighbors[i]->update = 1;
    
    return;
}


void CS2D_SetInput(int space, int row,int col, void* value, int input_id){
  CellSpace2D *s;

  //ModelicaFormatMessage("input to M[%d][%d] from %d = %f\n",row,col,input_id,value);
  s = (CellSpace2D *)space;
  if (s->M[row-1][col-1].inputs[input_id-1] != NULL) // free previous input
      free(s->M[row-1][col-1].inputs[input_id-1]);
  s->M[row-1][col-1].inputs[input_id-1] = value;
  s->M[row-1][col-1].inputs_rcv[input_id-1] = 1;
  s->M[row-1][col-1].update = 1;
  
  return;
}


void *CS2D_Get(int space, int row,int col){
  CellSpace2D *s;
  
  s = (CellSpace2D *)space;
  return s->M[row-1][col-1].cellstate;
}


int CS2D_SizeRows(int space){
  CellSpace2D *s;
  
  s =(CellSpace2D *)space;
  return s->nrows;
}

int CS2D_SizeCols(int space){
  CellSpace2D *s;
  
  s =(CellSpace2D *)space;
  return s->ncols;
}


void CS2D_Step(int space,void* (*rule)(void*,void**,int,int*,void**,int,int*),double (*display)(void*)){
  void ***new;//[s->nrows][s->ncols];
  int i,j,k,n;
  CellSpace2D *s;
  void **neighbors;
  
  s = (CellSpace2D *)space;
  new = (void ***)malloc(sizeof(void **)*s->nrows);
  for(i=0;i<s->nrows;i++)
    new[i] = (void **)malloc(sizeof(void*)*s->ncols);

  // dynamic memory for neighbors
  neighbors = (void **)malloc(sizeof(void *)*s->n_neighbors);
  
  // calculate and plot new cellstates
  if(s->plot_animation)
      fprintf(s->gp,"plot \'-\' matrix with image\n");
  //printf("plot \'-\' matrix with image\n");
  for(i=0;i<s->nrows;i++){
      for(j=0;j<s->ncols;j++){
          if (s->M[i][j].update){ // evaluate cell due to change in state, neighbors or inputs
              // join neighbor states
              for(k=0;k<s->n_neighbors;k++)
                  if (s->M[i][j].neighbors_present[k]){
                      neighbors[k] = s->M[i][j].neighbors[k]->cellstate;
		      //ModelicaFormatMessage("[%d,%d].NE[%d] = [%d,%d]\n",i,j,k,s->M[i][j].neighbors[k]->row,s->M[i][j].neighbors[k]->col);
		  }
              // Execute transition function
              new[i][j] = rule(s->M[i][j].cellstate,neighbors,s->n_neighbors,s->M[i][j].neighbors_present,s->M[i][j].inputs,s->n_inputs,s->M[i][j].inputs_rcv);
              //ModelicaFormatMessage("Step [%d][%d] = %f \n ",i+1,j+1,new[i][j]);
              for (k=0;k<s->n_inputs;k++){ //free inputs
		  free(s->M[i][j].inputs[k]);
		  s->M[i][j].inputs[k] = NULL;
                  s->M[i][j].inputs_rcv[k] = 0;
	      }
              s->M[i][j].update = 0; // reinit update flag
	      if(s->plot_animation)
		  fprintf(s->gp,"%f ",display(new[i][j]));
	  }else{
              //new[i][j] = s->M[i][j].cellstate;
	      new[i][j] = NULL;
	      //ModelicaFormatMessage("- Skip [%d][%d] = %f \n",i+1,j+1,new[i][j]);// cell not evaluated
	      if(s->plot_animation)
		  fprintf(s->gp,"%f ",display(s->M[i][j].cellstate));
          }	  
      }
      if(s->plot_animation)
          fprintf(s->gp,"\n");
      //printf("\n");
  }
  if(s->plot_animation){
      fprintf(s->gp,"\n");
      //printf("\n");
      fprintf(s->gp,"e\n");
      //printf("e\n");
#ifdef _WIN32
      Sleep(s->displayDelay/1000);
#else
      usleep(s->displayDelay);
#endif
      fflush(s->gp);
  }
  
  
  // update cell and neighbor states
  for(i=0;i<s->nrows;i++)
      for(j=0;j<s->ncols;j++){
          if (new[i][j] != NULL){
	      free(s->M[i][j].cellstate);
              s->M[i][j].cellstate = new[i][j];
	      new[i][j] = NULL;
              // update neighbors
              for(k=0;k<s->n_neighbors;k++){
                  if (s->M[i][j].neighbors_present[k])
                      s->M[i][j].neighbors[k]->update = 1;
		  neighbors[k] = NULL; // free pointers to neighbors
	      }
              s->M[i][j].update = 1;
          }       
      }
  free(new);
  free(neighbors);
  return;
}

void CS2D_NSteps(int N, int space, void * (*rule)(void*,void**,int,int *,void**,int,int*),double (*display)(void*)){
    int i;
  
  for (i=0;i<N;i++)
      CS2D_Step(space,rule,display);
  
  return;
}


#endif


