/**********************************************************
* Author: 
*        Victorino Sanz 
*        Dpto. Informática y Automática, UNED
*        Juan del Rosal, 16
*        28040, Madrid
*        Spain
*        Email: vsanz@dia.uned.es
*
* Licensed by Victorino Sanz under the Modelica License 2
* Copyright © 2013, Victorino Sanz.
* 
***********************************************************/

#ifndef TUMOUR
#define TUMOUR

#include <CellularAutomataLib.c>
#include <RngStream.c>

/****************************************/
/* TUMOUR CELLULAR AUTOMATA       */
/****************************************/

//**************************************
// Cell state
// User may redefine the state of the cell as desired
typedef struct State{
    int o; // cell occupation (0 empty, 1, normal, 2 cancer, 3 vessel)
    int s; // cell status (0 quiescent, 1 proliferative)
    int clock; // quiescent clock
    double ox; // local oxygen concentration
    int divpos;
}State;



//**************************************
// CELLULAR SPACE FUNCTIONS

// Function that allocates memory and sets the default state for the cells
void * DefaultState(){
    State *s;
    s = (State *)malloc(sizeof(State));
    
    //set the default values for state variables
    s->o = 0; // empty
    s->s = 1; // proliferative
    s->clock = 0;
    s->ox = 0; // 0 oxigen
    s->divpos = -1;
    return (void *)s;
}

// cellular space constructor
int Create(int nrows, int ncols, int *neighborhood, size_t n1, size_t n2, int n_inputs, int wrapped_borders,int plot_animation, int plot_range,int displayDelay, const char *path,const char *name){    
    void * (*defaultState)() = &DefaultState;
    return CS2D_Create(nrows, ncols, neighborhood, n1, n2, n_inputs, wrapped_borders,plot_animation,plot_range,displayDelay,path,name, defaultState);
}

// Function that describes the state of initialized cells (non-initialized cells will remain in the default state)
void InitialState(void *cell){
    State *s;
    
    s = (State *)cell;
    // set the values of state variables for initialized cells
    s->o = 3; // vessel
    
    return;
}

// initializing function for the selected cell
void Ini(int space, int row, int col){
    void  (*initialState)(void *) = &InitialState;
    CS2D_Init(space, row, col, initialState);
    return;
}

//***************************************************
// RULE FUNCTION
void *transition(void* cellstate, void** neighbors, int n_neighbors, int *neighbors_present, void** inputs, int n_inputs, int *inputs_rcv){
    State *out;
    State *cs;
    State **ne;
    State **in;
    double NT1 = 0.00045;
    double NT2 = 0.0045;
    double CT1 = 0.000015;
    double CT2 = 0.000045;
    double th;
    int CLOCK_LIMIT;
    int c,i;
    int divide,divpos;
    double maxox;
    
    cs = (State *)cellstate;
    ne = (State **)neighbors;
    in = (State **)inputs;
    out = (State *)malloc(sizeof(State));
    
    // define the behavior of the model during transitions

    *out = *cs;
    out->ox = 0.005;

    divide = 0;
    if (out->o == 0){ // EMPTY
	for(i=0;i<n_neighbors;i++){
	    if(neighbors_present[i]){
		if(ne[i]->divpos == mod(i+(n_neighbors/2),n_neighbors)){
		    out->o = ne[i]->o;
		    out->s = ne[i]->s;
		    out->ox = ne[i]->ox;
		    out->clock = 0;
		    out->divpos = -1;
		}
	    }
	}
    }
    
    if (out->o == 1){ // NORMAL
	c = 0;
	for(i=0;i<n_neighbors;i++){
	    if(neighbors_present[i]){
		if (ne[i]->o == 1) 
		    c++; //normal neighbor
		else if (ne[i] == 2) 
		    c--; // cancer neighbor
 		if (c >= 0)
		    th = NT1;
		else
		    th = NT2;
	    }
	}
	//	ModelicaFormatMessage("Normal step th = %f\n",th);
	if (out->ox >= th){
	    divide = 1; // division
	}else{ // dies
	    out->o = 0;
	}
    }
    if (out->o == 2){ // CANCER
	//ModelicaFormatMessage("cancer step\n");
	c = 0;
	for(i=0;i<n_neighbors;i++){
	    if(neighbors_present[i]){
		if(ne[i]->o == 1) 
		    c++; //normal neighbor
		else if (ne[i] == 2) 
		    c--; // cancer neighbor
		if (c >= 0)
		    th = CT2;
		else
		    th = CT1;
	    }
	}
	if (out->ox >= th){
	    out->clock = 0; // reset clock
	    divide = 1; // division
	}else{ // quiescent
	    if(out->s == 1){
		out->clock++;
		if (out->clock > CLOCK_LIMIT){ //dies
		    out->o = 0; // emtpy
		    out->clock = 0;
		    out->s = 1;
		}
	    }else{
		out->s = 1;
		out->clock = 0;
	    }
	}
    }
    if (out->o == 3){ // VESSEL
    }
    
    if (divide){
    	maxox = 0;
    	out->divpos = -1;
    	for(i=0;i<n_neighbors;i++){
    	    if(neighbors_present[i]){
    		if(ne[i]->ox >=  maxox && ne[i]->o == 0){
    		    maxox = ne[i]->ox;
    		    out->divpos = i;
    		}
    	    }
    	}
    }
    
    return (void *)out;
}

// Function that returns the value to display in the graphical animation
double Display(void *cell){
    State *s;
    double out;

    s = (State *)cell;
    // set out to the desired value calculated from the state variables
    out = s->o;

    return out;
}

int Step(int space){
    void* (*rule)(void*,void**,int,int*,void**,int,int*) = &transition;
    double (*display)(void*) = &Display;
    
    CS2D_Step(space,rule,display);
    return 1;
}

/*********************************************/

//**************************************
// INTERFACE FUNCTIONS


// function initialize a cell using an external value
void ExtInit(int space,int row, int col, double value){
    State* s;
    RngStream g = RngStream_CreateStream("tumour");
    double u;

    s = (State *)CS2D_Get(space,row,col);
    // assign external value to the state variables
    
    s->o = 0; // empty by default
    s->s = 1; // proliferative
    s->ox = 0; // 0 oxigen
    s->clock = 0;
    s->divpos = -1;

    //VESSELS 16 cols x 8 rows
    switch(mod(row,8)){
    case 1: if (mod(col,16)> 10 && mod(col,16) < 17)
	    s->o = 3; //vessel
	break;
    case 2: if (mod(col,16) == 0 || mod(col,16) == 10)
	    s->o = 3; //vessel
	break;
    case 3: if (mod(col,16) == 1 || mod(col,16) == 9)
	    s->o = 3; //vessel
	break;
    case 4: if (mod(col,16) == 2 || mod(col,16) == 8)
	    s->o = 3; //vessel
	break;
    case 5: if (mod(col,16) > 2 && mod(col,16) < 8)
	    s->o = 3; //vessel
	break;
    case 6: if (mod(col,16) == 2 || mod(col,16) == 8)
	    s->o = 3; //vessel
	break;
    case 7: if (mod(col,16) == 1 || mod(col,16) == 9)
	    s->o = 3; //vessel
	break;
    case 0: if (mod(col,16) == 0 || mod(col,16) == 10)
	    s->o = 3; //vessel
	break;
    }
    if (row >= 20 && row <= 30 && col >=20 &&  col <= 30 && s->o == 0){
	u = RngStream_RandU01(g);
	if (u >= 0.5)
	    s->o = 1; // normal
	else
	    s->o = 2; // cancer
    }
    CS2D_Init(space,row,col,NULL);
    return;
}

// Function to set a new input to a cell, from other cellular space
void SetInput(int Fspace, int Frow, int Fcol, int Tspace, int Trow, int Tcol, int input_id){
    State* s;
    State* inp;
    
    inp = (State *)malloc(sizeof(State));
    s = (State *)CS2D_Get(Fspace,Frow,Fcol);
    *inp = *s;
    CS2D_SetInput(Tspace,Trow,Tcol,(void*)inp,input_id);
}


// function to set an external value as an input to a cell
void ExtInput(int space,int row, int col, double value,int input_id){
    State* inp;

    inp = (State *)malloc(sizeof(State));
    //convert the external value to values of the state variables
    inp->o = value;

    CS2D_SetInput(space,row,col,(void*)inp,input_id);

    return;
}

// function to convert the state of a cell into a double value
double Output(int space, int row, int col){
    double out;
    
    out = Display(CS2D_Get(space,row,col));
    
    return out;
}

#endif
