/**********************************************************
* Author: 
*        Victorino Sanz 
*        Dpto. Informática y Automática, UNED
*        Juan del Rosal, 16
*        28040, Madrid
*        Spain
*        Email: vsanz@dia.uned.es
*
* Licensed by Victorino Sanz under the Modelica License 2
* Copyright © 2013, Victorino Sanz.
* 
***********************************************************/

#ifndef EPIDEMICS
#define EPIDEMICS

#include <CellularAutomataLib.c>


/****************************************/
/* EPIDEMICS CELLULAR AUTOMATA       */
/****************************************/

//**************************************
// Cell state
// User may redefine the state of the cell as desired
typedef struct State{
    double N; //total population
    double S; // susceptible
    double I; // infected
    double R; // recovered
}State;



//**************************************
// CELLULAR SPACE FUNCTIONS

// Function that allocates memory and sets the default state for the cells
void * DefaultState(){
    State *s;
    s = (State *)malloc(sizeof(State));
    
    //set the default values for state variables
    s->N = 1;
    s->S = 1;
    s->I = 0;
    s->R  = 0;
    return (void *)s;
}

// cellular space constructor
int Create(int nrows, int ncols, int *neighborhood, size_t n1, size_t n2, int n_inputs, int wrapped_borders,int plot_animation, int plot_range,int displayDelay, const char *path,const char *name){    
    void * (*defaultState)() = &DefaultState;
    return CS2D_Create(nrows, ncols, neighborhood, n1, n2, n_inputs, wrapped_borders,plot_animation,plot_range,displayDelay,path,name, defaultState);
}

// Function that describes the state of initialized cells (non-initialized cells will remain in the default state)
void InitialState(void *cell){
    State *s;
    
    s = (State *)cell;
    // set the values of state variables for initialized cells
    s->N = 1;
    s->S = 0.7;
    s->I = 0.3;
    s->R  = 0;

    return;
}

// initializing function for the selected cell
void Ini(int space, int row, int col){
    void  (*initialState)(void *) = &InitialState;
    CS2D_Init(space, row, col, initialState);
    return;
}

//***************************************************
// RULE FUNCTION
void *transition(void* cellstate, void** neighbors, int n_neighbors, int *neighbors_present, void** inputs, int n_inputs, int *inputs_rcv){
    State *out;
    State *cs;
    State **ne;
    State **in;
    double epsilon = 0.4;
    double v = 0.6;
    double c = 1;
    double m = 0.5;
    double mu  = c*m*v;
    double sum;
    int i;

    cs = (State *)cellstate;
    ne = (State **)neighbors;
    in = (State **)inputs;
    out = (State *)malloc(sizeof(State));
    
    // define the behavior of the model during transitions
    sum = 0;
    for(i=0;i<n_neighbors;i++){
	if(neighbors_present[i]){
	    //sum = sum + (ne[i]->N/cs->N)*mu*ne[i]->I;
	    sum = sum + mu*ne[i]->I;
	}
    }

    out->I = (1-epsilon)*cs->I + v*cs->S*cs->I + cs->S*sum;
    out->S = cs->S - v*cs->S*cs->I -cs->S*sum;
    out->R = cs->R + epsilon*cs->I;

    return (void *)out;
}

// Function that returns the value to display in the graphical animation
double Display(void *cell){
    State *s;
    double out;

    s = (State *)cell;
    // set out to the desired value calculated from the state variables
    out = s->I;

    return out;
}

int Step(int space){
    void* (*rule)(void*,void**,int,int*,void**,int,int*) = &transition;
    double (*display)(void*) = &Display;
    
    CS2D_Step(space,rule,display);
    return 1;
}

/*********************************************/

//**************************************
// INTERFACE FUNCTIONS


// function initialize a cell using an external value
void ExtInit(int space,int row, int col, double value){
    State* s;

    s = (State *)CS2D_Get(space,row,col);
    // assign external value to the state variables
    s->I = value;
    CS2D_Init(space,row,col,NULL);
    return;
}


// Function to set a new input to a cell, from other cellular space
void SetInput(int Fspace, int Frow, int Fcol, int Tspace, int Trow, int Tcol, int input_id){
    State* s;
    State* inp;
    
    inp = (State *)malloc(sizeof(State));
    s = (State *)CS2D_Get(Fspace,Frow,Fcol);
    *inp = *s;
    CS2D_SetInput(Tspace,Trow,Tcol,(void*)inp,input_id);
}


// function to set an external value as an input to a cell
void ExtInput(int space,int row, int col, double value,int input_id){
    State* inp;

    inp = (State *)malloc(sizeof(State));
    //convert the external value to values of the state variables
    inp->I = value;

    CS2D_SetInput(space,row,col,(void*)inp,input_id);

    return;
}

// function to convert the state of a cell into a double value
double OutputS(int space, int row, int col){
    double out;
    State* s;
    
    s = (State *)CS2D_Get(space,row,col);
    
    out = s->S;
    
    return out;
}

// function to convert the state of a cell into a double value
double OutputI(int space, int row, int col){
    double out;
    State* s;
    
    s = (State *)CS2D_Get(space,row,col);
    
    out = s->I;
    
    return out;
}

// function to convert the state of a cell into a double value
double OutputR(int space, int row, int col){
    double out;
    State* s;
    
    s = (State *)CS2D_Get(space,row,col);
    
    out = s->R;
    
    return out;
}

#endif
