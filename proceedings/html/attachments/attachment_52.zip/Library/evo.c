/**********************************************************
* Author: 
*        Victorino Sanz 
*        Dpto. Informática y Automática, UNED
*        Juan del Rosal, 16
*        28040, Madrid
*        Spain
*        Email: vsanz@dia.uned.es
*
* Licensed by Victorino Sanz under the Modelica License 2
* Copyright © 2013, Victorino Sanz.
* 
***********************************************************/

#ifndef EVO
#define EVO

#include <gsl/gsl_rng.h>
#include <ComplexCA.c>


/****************************************/
/* DRAFT CELLULAR AUTOMATA       */
/****************************************/

//**************************************
// Cell state
// User may redefine the state of the cell as desired
typedef struct State{
    int phase; // 0 empty, 1 infant, 2 adult
    double sigma;
    int action; // -1 dead, 0 passive/living, 4 send phase to neigbor, 1 reproduction, 2 postmutation, 3 changestate, 5 ask neighbor to update phase
    int age;
    int ngen; // number of genes
    int nmod; // number of modules
    int genrel[2][2]; // nget x ngen matrix of inter-genetic relations
    int genval[2]; // nmod vector of genetic values
    int modrel[2][2]; // ngen x nmod matrix for relation between genes and modules
    double pchangegen[2][2]; // ngen x ngen matrix of probabilities for changes in GENREL
    double pchangemod[2][2]; // ngen x nmod matrix of probabilities for changes in MODREL
    int eMOD[2]; // nmod vector of values for modules
    int neighbors[8]; // phase of neighbors
    int filogenetics[8]; // filogenetic position
    int nextRepr; // place for next reproduction
    int environment;
    double stress;
    double stth; // stress threshold for mutations;
    double Tlasttran; // time of last transition
    int updateport[8]; // port of neighbors to update
    gsl_rng *g;
    FILE *outfile;
    double t;
}State;



//**************************************
// CELLULAR SPACE FUNCTIONS

// Function that allocates memory and sets the default state for the cells
void * DefaultState(){
    State *s;
    s = (State *)malloc(sizeof(State));
    
    //set the default values for state variables
    s->phase = 0;
    s->sigma = DBL_MAX;// Modelica.Constants.inf; // first internal event never happens
    s->action = 0; // passive
    s->age = 0;
    s->genrel= [1,0; 0,1];
    s->genval = {6,15};
    s->modrel = [1,1; 1,0];
    s->pchangegen = [0.2,0.8; 0.5,0.2];
    s->pchangemod = [0.5,0.2; 0.2,0.8];
    s->eMOD = {0,0};
    s->ngen = 2;  // number of genes = 2
    s->nmod = 2; // number of modules = 2
    s->neighbors = {0,0,0,0,0,0,0,0}; // phase of neighbors
    s->filogenetics = {0,0,0,0,0,0,0,0};
    s->nextRepr = 0;
    s->environment = 10; // default environment level
    s->stress = 0; // default stress level
    s->stth = 0.8; // default stress threshold
    s->Tlasttran = 0; // time of last transition
    s->updateport = {0,0,0,0,0,0,0,0};
    s->g := gsl_rng_alloc(gsl_rng_cmrg);
    s->outfile= fopen("OUTPUT.txt","w+");
    
    return (void *)s;
}

// cellular space constructor
int Create(int nrows, int ncols, int *neighborhood, size_t n1, size_t n2, int n_inputs, int wrapped_borders,int plot_animation, int plot_range,int displayDelay, const char *path,const char *name){    
    void * (*defaultState)() = &DefaultState;
    return CS2D_Create(nrows, ncols, neighborhood, n1, n2, n_inputs, wrapped_borders,plot_animation,plot_range,displayDelay,path,name, defaultState);
}

// Function that describes the state of initialized cells (non-initialized cells will remain in the default state)
void InitialState(void *cell){
    State *s;
    
    s = (State *)cell;
    // set the values of state variables for initialized cells
    //set the default values for state variables
    s->phase = 0;
    s->sigma = DBL_MAX;// Modelica.Constants.inf; // first internal event never happens
    s->action = 0; // passive
    s->age = 0;
    s->genrel= [1,0; 0,1];
    s->genval = {6,15};
    s->modrel = [1,1; 1,0];
    s->pchangegen = [0.2,0.8; 0.5,0.2];
    s->pchangemod = [0.5,0.2; 0.2,0.8];
    s->eMOD = {0,0};
    s->ngen = 2;  // number of genes = 2
    s->nmod = 2; // number of modules = 2
    s->neighbors = {0,0,0,0,0,0,0,0}; // phase of neighbors
    s->filogenetics = {0,0,0,0,0,0,0,0};
    s->nextRepr = 0;
    s->environment = 10; // default environment level
    s->stress = 0; // default stress level
    s->stth = 0.8; // default stress threshold
    s->Tlasttran = 0; // time of last transition
    s->updateport = {0,0,0,0,0,0,0,0};
     
    return;
}

// initializing function for the selected cell
void Initial(int space, int row, int col){
    void  (*initialState)(void *) = &InitialState;
    CS2D_Init(space, row, col, initialState);
    return;
}

//***************************************************
// RULE FUNCTION
void *transition(void* cellstate, void** neighbors, int n_neighbors, int *neighbors_present, void** inputs, int n_inputs, int *inputs_rcv){
    State *out;
    State *cs;
    State **ne;
    State **in;
    double env;
    double str;
    int n,i,j,dead;
    double u;
    int valGEN[2];
    
    

    cs = (State *)cellstate;
    ne = (State **)neighbors;
    in = (State **)inputs;
    out = (State *)malloc(sizeof(State));
    
    // define the behavior of the model during transitions
    *out = *s;
    env = in[0]; // first input is the environment
    str = in[1]; // second input is the stress
    out->updateport = {0,0,0,0,0,0,0,0}; // reset update ports
    if (out->action == 0){ // usual life cicle transition
	/****** MUTATION GENREL **********/
	n = 0;
	for(i=1;i<out->ngen:i++){ // change GENREL
	    for(j=1;j<out->ngen;j++){
		u = gsl_rng_uniform(out->g); // U[0,1] random variate
		if (out->pchangegen[i][j] >= u and str >= out->stth and i == 1 and j == 1){ // pchangen and stress
		    out->genrel[i][j] = 1 - out->genrel[i][j];
		    out->pchangegen[i][j] = 0.1;
		    n++;
		}else if (out->pchangegen[i][j] >= u and str >= out->stth+0.05 and i == 1 and j == 2){ // pchangen and stress
		    out->genrel[i][j] = 1 - out->genrel[i][j];
		    out->pchangegen[i][j] = 0.1;
		    n++;
		}else if (out->pchangegen[i][j] >= u and str >= out->stth+0.1 and i == 2 and j == 1){ // pchangen and stress
		    out->genrel[i][j] = 1 - out->genrel[i][j];
		    out->pchangegen[i][j] = 0.1;
		    n++;
		}else if(out->pchangegen[i][j] >= u and str >= out->stth+0.15 and i == 2 and j == 2){ // pchangen and stress
		    out->genrel[i][j] = 1 - out->genrel[i][j];
		    out->pchangegen[i][j] = 0.1;
		    n++;
		}else if (u <= 0.001){ // probabilidad de mutacion sin estres
		    out->genrel[i][j] := 1 - out->genrel[i][j];
		    n++;
		}
	    }
	}
	if (n > 0)
	    fprintf(s->outfile,"MUTACION GENREL ["+String(n)+"]");
	end if;
	n= 0;
	for(i=1;i<out->ngen;i++){ // change MODREL
	    for(j=1;j<out->nmod;j++){
	    	u = gsl_rng_uniform(out->g); // U[0,1] random variate
		if (out->pchangemod[i][j] >= u and str >= out->stth+0.025 and i == 1 and j == 1){
		    out->modrel[i][j] = 1 - out->modrel[i][j];
		    out->pchangemod[i][j] = 0.1;
		    n++;
		}else if (out->pchangemod[i][j] >= u and str >= out->stth+0.075 and i == 1 and j == 2){
		    out->modrel[i][j] = 1 - out->modrel[i][j];
		    out->pchangemod[i][j] = 0.1;
		    n++;
		}else if (out->pchangemod[i][j] >= u and str >= out->stth+0.125 and i == 2 and j == 1){
		    out->modrel[i][j] = 1 - out->modrel[i][j];
		    out->pchangemod[i][j] = 0.1;
		    n++;
		}else if (out->pchangemod[i][j] >= u and str >= out->stth+0.175 and i == 2 and j == 2){
		    out->modrel[i][j] := 1 - out->modrel[i][j];
		    out->pchangemod[i][j] := 0.1;
		    n++;
		}else if (u <= 0.001){ // probabilidad de mutacion sin estres
		    out->modrel[i][j] = 1 - out->modrel[i][j];
		    n++;
		}
	    }
	}
	if (n > 0)
	    fprint(s->outfile,"MUTACION MODREL ["+String(n)+"]");
	/****** MUTATION GENVAL **********/
	n=0;
	for(i=1;i<out->nmod;i++){
	    if (str >= out->stth) // stress greater than threshold
		probmut = 0.3;
	    else
		probmut = 0.003;
	    u = gsl_rng_uniform(out->g); // U[0,1] random variate
	    if (u <= probmut){ // modify GENVAL depending on probmut
		u = gsl_ran_flat(out->g,cs->genval[i]-3,cs->genval[i]+3);
		out->genval[i] = (int)u;
		n++;
		//Modelica.Utilities.Streams.print("MUTACION GENVAL", "OUTPUT.txt");
	    }
	}
	if (n > 0)
	    fprint(s->outfile,"MUTACION GENVAL ["+String(n)+"]");
    /****** COMPROBACION VIABILIDAD ***/
	dead = 0;
	// calcular valGEN
	valGEN = {0,0};
	for( i=1;i<out->ngen;i++){
	    for(j=1;j<out->ngen;j++){
		valGEN[i] = valGEN[i] + out->genval[j]*out->genrel[i][j];
	    }
	}
	// calcular expresionMOD (eMOD)
	out->eMOD = {0,0};
	for(i=1;i<out->nmod;i++){
	    for(j=1;j<out->ngen;j++){
		out->eMOD[i] = out->eMOD[i] + valGEN[j]*out->modrel[i][j];
	    }
	}
	// FILTRO AMBIENTE
	if (out->phase > 0){
	    for (i=1;i<out->nmod;i++){
		if (i == 1){
		    if ((out->eMOD[i] < env or out->eMOD[i] > 3*env) && s.age > 0){
			// DEAD by environment
			//Modelica.Utilities.Streams.print("DEAD by environment");
			dead = 1;
			fprint(s->outfile,"DEAD by environment (eMOD1 < env, eMOD1 > 3*env) ENV=%f\n",env);
			InitialState((void*)out); // reinit state
			out->environment = (int)env;
			out->stress = str;
		    }
		}else if (i == 2){
		    if  ((out->eMOD[i] < env/2 or out->eMOD[i] > 2*env) && s.age > 0){
			// DEAD by environment
			//Modelica.Utilities.Streams.print("DEAD by environment");
			dead = 1;
			fprint(s->outfile,"DEAD by environment (eMOD2 < env/2, eMOD2 > 2*env) ENV=%f\n",env);
			InitialState((void*)out); // reinit state
			out->environment = (int)env;
			out->stress = str;
		    }
		}
	    }
	}
	// FILTRO RESTRICCION EMBRIOLOGICA
	if (out->phase > 0){
	    for(i=1;i<out->nmod;i++){
		if (i == 1){
		    if (((out->eMOD[i] > 2 and out->eMOD[i] < 5) || 
			 (out->eMOD[i] > 10 and out->eMOD[i] < 15) || 
			 (out->eMOD[i] > 25 and out->eMOD[i] < 30)) && s.age > 0){ then
			    // DEAD by embrio restriction
			    dead = 1;
			fprint(s->outfile,"%d DEAD by embrio restriction (eMOD1)\n",out->eMOD[i]);
			InitialState((void*)out);// reinit state
			out->environment = (int)env;
			out->stress = str;
		    }
		}else if (i == 2){
		    if (((out->eMOD[i] > 8 and out->eMOD[i] < 10) || 
			 (out->eMOD[i] > 23 and out->eMOD[i] < 25) || 
			 (out->eMOD[i] > 33 and out->eMOD[i] < 38)) && s.age > 0){
			// DEAD by embrio restriction
			dead = 1;
			fprint(out->outfile,"%d DEAD by embrio restriction (eMOD2)\n",out->eMOD[i]);
			InitialState((void*)out); // reinit state
			out->environment = (int)env;
			out->stress = str;
		    }
		}
	    }
	}
	// FILTRO EDAD
	if (out->phase > 0 && !dead){
	    if (out->age >= 10){
		// DEAD by age
		dead = 1;
		fprint(out->outfile,"DEAD by age\n");
		InitialState((void*)out); // reinit state
		out->environment := (int)env;
		out->stress := str;
	    }
	}
	if (dead){ then
		//      if out->phase == 0 and dead then // DIED - send phase update to neigbors
		out->action := 4; //send phase update to neigbors
	    out->updateport := s.neighbors;
	    out->sigma := 0; // generate output.
	    //      end if;
	}else{
	    /****** REPRODUCTION ******/
	    // adulto => edad > 1 (1 cicle without reprod.)
	    if (out->age > 1 and out->phase > 0){
		//Modelica.Utilities.Streams.print("Reproducing ...");
		out->action = 1; // Reproduce using output function
		out->sigma = 0; // inmediate internal transition to generate output
		// find empty neighbor
		kl = {0,0,0,0,0,0,0,0};
		j = 1;
		for(i=1;i<8;i++){
		    if (s.neighbors[i] == 0){
			kl[j] = i;
			j++;
			found = 1;
		    }
		}
		if (found){ // found empty neighbor
		    // select random neighbor between those in kl
		    u = gsl_rng_uniform(out->g); // U[0,1] random variate
		    out->nextRepr = kl[integer(u*(j-1))+1];
		    out->filogenetics[out->nextRepr] = 1;
		}else
		    out->nextRepr = 0;
	    }else
		out->sigma = 1; // next life cicle
	    /****** UPDATE AGE *********/
	    //     if out->phase > 0 then // still alive
	    out->age++;
	    //Modelica.Utilities.Streams.print("ACTION = "+String(out->action)+" SIGMA = "+String(out->sigma)+": AGE UPDATED FROM "+String(s.age)+" TO "+String(out->age),"OUTPUT.txt");
	    if (out->age <= 1)
		out->phase = 1; //infant
	    else
		out->phase = 2; // adult
	    /** NEXT TRANSITION **/
	}
    }else{ // empty internal transition after output generation
	//Modelica.Utilities.Streams.print("EMPTY INTERNAL");
	out->action = 0; // passive
	if (out->phase > 0)
	    out->sigma = 1; // new life cicle
	else
	    out->sigma := Modelica.Constants.inf; // empty cell
	end if;
    }
    
    
    return (void *)out;
}

// Function that returns the value to display in the graphical animation
double Display(void *cell){
    State *s;
    double out;

    s = (State *)cell;
    // set out to the desired value calculated from the state variables
    out = s->t;

    return out;
}

int Step(int space){
    void* (*rule)(void*,void**,int,int*,void**,int,int*) = &transition;
    double (*display)(void*) = &Display;
    
    CS2D_Step(space,rule,display);
    return 1;
}

/*********************************************/

//**************************************
// INTERFACE FUNCTIONS


// function initialize a cell using an external value
void ExtInit(int space,int row, int col, double value){
    State* s;

    s = (State *)CS2D_Get(space,row,col);
    // assign external value to the state variables
    s->t = value;
    
    return;
}


// Function to set a new input to a cell, from other cellular space
void SetInput(int Fspace, int Frow, int Fcol, int Tspace, int Trow, int Tcol, int input_id){
    State* s;
    State* inp;
    
    inp = (State *)malloc(sizeof(State));
    s = (State *)CS2D_Get(Fspace,Frow,Fcol);
    *inp = *s;
    CS2D_SetInput(Tspace,Trow,Tcol,(void*)inp,input_id);
}


// function to set an external value as an input to a cell
void ExtInput(int space,int row, int col, double value,int input_id){
    State* inp;

    inp = (State *)malloc(sizeof(State));
    //convert the external value to values of the state variables
    inp->t = value;

    CS2D_SetInput(space,row,col,(void*)inp,input_id);

    return;
}

// function to convert the state of a cell into a double value
double Output(int space, int row, int col){
    double out;
    
    out = Display(CS2D_Get(space,row,col));
    
    return out;
}

#endif
