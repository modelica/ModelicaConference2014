/**********************************************************
* Author: 
*        Victorino Sanz 
*        Dpto. Informática y Automática, UNED
*        Juan del Rosal, 16
*        28040, Madrid
*        Spain
*        Email: vsanz@dia.uned.es
*
* Licensed by Victorino Sanz under the Modelica License 2
* Copyright © 2013, Victorino Sanz.
* 
***********************************************************/

#ifndef CHAGAS
#define CHAGAS

#include <CellularAutomataLib.c>
#include <RngStream.c>

/****************************************/
/* CHAGAS DISEASE CELLULAR AUTOMATA       */
/****************************************/

//**************************************
// Cell state
// User may redefine the state of the cell as desired
typedef struct State{
    int y; // number of young
    int a; // number of adults
    //  int ymax; // max young
    // int amax; // max adult
    int h; // habitat, 0= F(forest), 1 = G (garden), 2 = H (house)
    int Nin; // adults from neighbors
    int Nout[8]; // adults to neighbors
    RngStream g;
}State;



//**************************************
// CELLULAR SPACE FUNCTIONS

// Function that allocates memory and sets the default state for the cells
void * DefaultState(){
    State *s;
    int i;
    s = (State *)malloc(sizeof(State));
    
    //set the default values for state variables
    s->y = 0;
    s->a = 0;
    // s->ymax = 5;
    // s->amax = 5;
    s->h = 1;  
    s->Nin = 0;
    for(i=0;i<8;i++)
	s->Nout[i] = 0;
    s->g = RngStream_CreateStream("chagas");
    
    return (void *)s;
}

// cellular space constructor
int Create(int nrows, int ncols, int *neighborhood, size_t n1, size_t n2, int n_inputs, int wrapped_borders,int plot_animation, int plot_range,int displayDelay, const char *path,const char *name){    
    void * (*defaultState)() = &DefaultState;
    return CS2D_Create(nrows, ncols, neighborhood, n1, n2, n_inputs, wrapped_borders,plot_animation,plot_range,displayDelay,path,name, defaultState);
}

// Function that describes the state of initialized cells (non-initialized cells will remain in the default state)
void InitialState(void *cell){
    State *s;
    
    s = (State *)cell;
    // set the values of state variables for initialized cells
    s->y = 0;
    s->a = 5;
    s->h = 0; //forest
    
    return;
}

// initializing function for the selected cell
void Ini(int space, int row, int col){
    void  (*initialState)(void *) = &InitialState;
    CS2D_Init(space, row, col, initialState);
    return;
}

int binomial(RngStream g, double p, int t){
    int x=0,i;
    double u;
    for (i=0;i<t;i++){
	u = RngStream_RandU01(g);
	if (u <= p)
	    x = x +1;
    }
    //    ModelicaFormatMessage("binomial = %d\n",x);
    return x;
}


//***************************************************
// RULE FUNCTION
void *transition(void* cellstate, void** neighbors, int n_neighbors, int *neighbors_present, void** inputs, int n_inputs, int *inputs_rcv){
    State *out;
    State *cs;
    State **ne;
    State **in;
    int Nry=0,Nsy=0,Nsa=0,Nda=0,Nout=0,Nin=0,i,n;
    double Prg = 0.012333; // prob reproduction of adults in Garden
    double Prh = 0.004111; // prob reproduction of adults in Home
    int Fi = 1; // number of young per adult after reproduction
    double Psyg = 0.913812097; // prob survival young in Garden
    double Psyh = 0.90272518; // prob survival young in Home
    double Psag = 0.994879428; // prob survival adult in Garden
    double Psah = 0.9828095; // prob survival adult in Home
    double Pdg = 0.004158; // prob development in Garden
    double Pdh = 0.004158; // prob development in Home
    double Qf = 50; // Mean number of bugs arriving to the village per day
    double M = 900; // size of the space 
    double Df = Qf/4*M; // dispersal coeficient
    double r = 1; // dispersal radius of bugs
    double D = 0.9; // dispersal coefficient in the village
    double P = 0.5;//D/pow(2*r+1,2)-1; // prob of dispersion
    double u;


    cs = (State *)cellstate;
    ne = (State **)neighbors;
    in = (State **)inputs;
    out = (State *)malloc(sizeof(State));
    
    *out = *cs;
    // define the behavior of the model during transitions
    for(i=0;i<n_neighbors;i++)
	out->Nout[i] = 0;
    
    //    ModelicaFormatMessage("NEW STEP***************************\n");

    if (out->h > 0){
	for(i=0;i<n_neighbors;i++){
	    if(neighbors_present[i]){
		if(ne[i]->Nout[mod(i+4,n_neighbors)] > 0)
		    out->Nin = out->Nin + ne[i]->Nout[mod(i+4,n_neighbors)];
	    }
	}
	
	out->a = out->a+out->Nin; // update adults with dispersions from neighbors
        out->Nin = 0;
	
	//**  DEMOGRAPHY
	// Reproduction
	Nry = 0;
	if (out->h == 1){ //G
	    Nry = Fi*binomial(out->g,Prg,out->a); // number of larvae per adult times the number of adults reproducing
	}else if (out->h == 2){ //H
	    Nry = Fi*binomial(out->g,Prh,out->a); // number of larvae per adult times the number of adults reproducing
	}
	
	//out->y = out->y+Nry;
	
	// Survival
	Nsy =0;
	Nsa = 0;
	if (out->h == 1){ //G
	    Nsy = binomial(out->g,Psyg,out->y);
	    Nsa = binomial(out->g,Psag,out->a);
	}else if (out->h == 2){ //H
	    Nsy = binomial(out->g,Psyh,out->y);
	    Nsa = binomial(out->g,Psah,out->a);
	}
	
	// Development
	Nda =0;
	if (out->h == 1){ //G
	    Nda = binomial(out->g,Pdg,Nsy);
	}else if (out->h == 2){ //H
	    Nda = binomial(out->g,Pdh,Nsy);
	}
	out->a = Nsa + Nda; // survived + developed adults
	out->y = Nry + Nsy - Nda; // reproduced + survived - developed youngs
    }
    //**  DISPERSAL
    //ModelicaFormatMessage("DISPERSION\n");
    Nout = binomial(out->g,P,out->a);
    if(out->h > 0) 
	out->a = out->a-Nout;
    //send Nout to neighbors at random
    for(i=0;i<Nout;i++){
	//u = gsl_ran_flat(out->g,0,n_neighbors);
	//n = (int) u;
	n = RngStream_RandInt(out->g,0,n_neighbors-1);
	//ModelicaFormatMessage("n = %d\n",n);
	while(!neighbors_present[n]){
	    //ModelicaFormatMessage("preN=%d\n",n);// gsl_ran_discrete(out->g,discrete);
	    n = mod(n+1,n_neighbors);
	    //ModelicaFormatMessage("N=%d\n",n);// gsl_ran_discrete(out->g,discrete);
	    //u = gsl_ran_flat(out->g,0,n_neighbors);
	    //n = (int) u;
	}
	//ModelicaFormatMessage("[0,%d] disperstion to u = %f, n=%d\n",n_neighbors,u,n);
	//ne[n]->Nin++;
	out->Nout[n]++;
    }
    
    
    return (void *)out;
}

// Function that returns the value to display in the graphical animation
double Display(void *cell){
    State *s;
    double out;

    s = (State *)cell;
    // set out to the desired value calculated from the state variables
    if (s->a == 0)
	out = 0;
    else if (s->a == 1)
	out = 1;
    else
	out = 2;

    return out;
}

int Step(int space){
    void* (*rule)(void*,void**,int,int*,void**,int,int*) = &transition;
    double (*display)(void*) = &Display;
    
    CS2D_Step(space,rule,display);
    return 1;
}

/*********************************************/

//**************************************
// INTERFACE FUNCTIONS


// function initialize a cell using an external value
void ExtInit(int space,int row, int col, double value){
    State* s;

    s = (State *)CS2D_Get(space,row,col);
    // assign external value to the state variables
    s->y = 0;
    s->a = value;
    s->h = 0; //forest
    CS2D_Init(space,row,col,NULL);
    return;
}


// Function to set a new input to a cell, from other cellular space
void SetInput(int Fspace, int Frow, int Fcol, int Tspace, int Trow, int Tcol, int input_id){
    State* s;
    State* inp;
    
    inp = (State *)malloc(sizeof(State));
    s = (State *)CS2D_Get(Fspace,Frow,Fcol);
    *inp = *s;
    CS2D_SetInput(Tspace,Trow,Tcol,(void*)inp,input_id);
}


// function to set an external value as an input to a cell
void ExtInput(int space,int row, int col, double value,int input_id){
    State* inp;

    inp = (State *)malloc(sizeof(State));
    //convert the external value to values of the state variables
    inp->a = value;

    CS2D_SetInput(space,row,col,(void*)inp,input_id);

    return;
}

// function to convert the state of a cell into a double value
double OutputA(int space, int row, int col){
    double out;
    State* c;

    c = (State *)CS2D_Get(space,row,col);
    //convert the external value to values of the state variables
    out = c->a;
    
    return out;
}

// function to convert the state of a cell into a double value
double OutputY(int space, int row, int col){
    double out;
    State* c;

    c = (State *)CS2D_Get(space,row,col);
    //convert the external value to values of the state variables
    out = c->y;
    
    return out;
}

#endif
