/**********************************************************
* Author: 
*        Victorino Sanz 
*        Dpto. Informática y Automática, UNED
*        Juan del Rosal, 16
*        28040, Madrid
*        Spain
*        Email: vsanz@dia.uned.es
*
* Licensed by Victorino Sanz under the Modelica License 2
* Copyright © 2013, Victorino Sanz.
* 
***********************************************************/

#ifndef FOREST
#define FOREST

#include <CellularAutomataLib.c>
#include <Behave.c>

/****************************************/
/* FOREST CELLULAR AUTOMATA       */
/****************************************/

//**************************************
// Cell state
// User may redefine the state of the cell as desired
typedef struct State{
    Behave *b;
    int s; //  cell state (0 unburned, 1 burning, 2 burned)
    int wet; // 0 not wet, 1 wet
    double windspeed;
    int winddir;
    double slope;
    int timetoWet; // time to wet
    int *timetoSpread; // number of steps to reach neighbors
    int fuelmodel;
}State;



//**************************************
// CELLULAR SPACE FUNCTIONS

// Function that allocates memory and sets the default state for the cells
void * DefaultState(){
    State *s;
    s = (State *)malloc(sizeof(State));
    
    //set the default values for state variables
    s->s = 0; // unburned
    s->wet = 0; // not wet
    s->windspeed = 8.045;//2.2352; 
    s->winddir = 180; // blows FROM south
    s->slope = 0;
    s->timetoWet = 9999; //
    s->timetoSpread = NULL;
    s->fuelmodel = 4;

    s->b = (Behave *)malloc(sizeof(Behave));
    initialValues(s->b);
    setFuelModel(s->fuelmodel,s->b);
    setWindSpeed(s->windspeed,s->b);
    setWindDir(s->winddir,s->b);
    setSlope(s->slope,s->b);
    calcRothermel(s->b);     
    return (void *)s;
}

// cellular space constructor
int Create(int nrows, int ncols, int *neighborhood, size_t n1, size_t n2, int n_inputs, int wrapped_borders,int plot_animation, int plot_range,int displayDelay, const char *path,const char *name){    
    void * (*defaultState)() = &DefaultState;
    return CS2D_Create(nrows, ncols, neighborhood, n1, n2, n_inputs, wrapped_borders,plot_animation,plot_range,displayDelay,path,name, defaultState);
}

// Function that describes the state of initialized cells (non-initialized cells will remain in the default state)
void InitialState(void *cell){
    State *s;
    
    s = (State *)cell;
    // set the values of state variables for initialized cells
    s->s = 1;
    
    return;
}

// initializing function for the selected cell
void Ini(int space, int row, int col){
    void  (*initialState)(void *) = &InitialState;
    CS2D_Init(space, row, col, initialState);
    return;
}

//***************************************************
// RULE FUNCTION
void *transition(void* cellstate, void** neighbors, int n_neighbors, int *neighbors_present, void** inputs, int n_inputs, int *inputs_rcv){
    State *out;
    State *cs;
    State **ne;
    double **in;
    int ne_burning; // num of neighbors burning
    int ne_n; // num of neigbors
    double R[8];
    double D = 15; // distance between neighbors
    int i;

    cs = (State *)cellstate;
    ne = (State **)neighbors;
    in = (double **)inputs;
    out = (State *)malloc(sizeof(State));
    
    // define the behavior of the model during transitions
    
    *out = *cs;

    
    if(n_inputs > 0){
	// INPUT[2] and INPUT[3] wind direction and speed changed
	if (inputs_rcv[2]){ // direction
	    out->winddir = *in[2]; //	
	}
	if (inputs_rcv[3]){ // speed
	    out->windspeed = *in[3]; // 
	}
	setWindSpeed(out->windspeed,out->b);
	setWindDir(out->winddir,out->b);
	calcRothermel(out->b);    
	
	// INPUT[1] water poured or firefighting action
	if (inputs_rcv[1]){
	    out->timetoWet = *in[1]; // reset time to wet value
	    if (out->s == 0) // if unburned, set to wet
		out->wet = 1;
	}
	if (out->timetoWet <= 0)
	    out->wet = 1;    
	out->timetoWet--; 
    }
    // calculate Rothermel model and assign spread rates
    
    // ACTIONS
    if (out->s == 0 && !out->wet){ // unburned and not wet
	// INPUT[0] External ignition
	if(n_inputs > 0)
	    if (inputs_rcv[0]){
		out->s = 1;
	    }
	// Spread from neighbor
	for(i=0;i<n_neighbors;i++){
	    if(neighbors_present[i]){
		if(ne[i]->timetoSpread != NULL)
		    if(ne[i]->timetoSpread[mod(i+4,n_neighbors)] == 0 && !out->wet){ // not wet and fire spread from neighbor
			out->s = 1; //starts burning
		    }
	    }
	}
    }else if (cs->s == 1){ // burning
	if(out->timetoSpread == NULL){
	    out->timetoSpread = (int *)malloc(sizeof(int)*n_neighbors);
	    for(i=0;i<n_neighbors;i++){
		R[i] = getRosInDir(out->b->ros,out->b->sdr,-45+(i*45),out->b->ecc);
		//		ModelicaFormatMessage("ROS = %f, R[%d]=%f\n",out->b->ros,i,R[i]);
		//		ModelicaFormatMessage("spread direction = %f\n",out->b->sdr);
		//ModelicaFormatMessage("wind direction = %f\n",out->b->wdr);
		//ModelicaFormatMessage("fireline intensity = %f\n",out->b->fli);
		//ModelicaFormatMessage("eccentricity = %f\n",out->b->ecc);
		if (i % 2){
		    out->timetoSpread[i] = (D/R[i]); // linear connection between cells
		    //ModelicaFormatMessage("R[%d]= %f -> timetospread = %f : %d\n",i,R[i],D/R[i],out->timetoSpread[i]);
		}else{
		    out->timetoSpread[i] = (sqrt(2*pow(D,2))/R[i]); // diagonal connection between cells
		    //ModelicaFormatMessage("- R[%d]= %f -> timetospread = %f : %d\n",i,R[i],sqrt(2*pow(D,2))/R[i],out->timetoSpread[i]);
		}	
	    }
	}else{
	    for(i=0;i<n_neighbors;i++){
		out->timetoSpread[i]--;
	    }	
	}
	if(!out->wet){
	    ne_burning = 0; 
	    /* ne_n = 0; */
	    /* for(i=0;i<n_neighbors;i++){ */
	    /* 	if(neighbors_present[i]){ */
	    /* 	    if (ne[i]->s > 0) // neighbor burning or burned */
	    /* 		ne_burning++; // number of neighbors burning or burned */
	    /* 	    ne_n++; // number of neighbors (ne_n != n_neighbors for border cells) */
	    /* 	} */
	    /* } */
	    /* if (ne_burning == ne_n) // all neighbors burning or burned? */
	    /* 	out->s = 2; // to burned */
	    for(i=0;i<n_neighbors;i++){
		if (out->timetoSpread[i] <= 0)
		    ne_burning++;
	    }
	    //ModelicaFormatMessage("burning = %d, ne = %d\n",ne_burning,n_neighbors);
	    if(ne_burning == n_neighbors)
		out->s = 2; // to burned
	}else{
	    out->s = 2; // to burned due to wet
	}
    }else if (out->s == 2){ // burned
    }
    

    return (void *)out;
}

// Function that returns the value to display in the graphical animation
double Display(void *cell){
    State *s;
    double out;

    s = (State *)cell;
    // set out to the desired value calculated from the state variables
    out = s->s;

    return out;
}

int Step(int space){
    void* (*rule)(void*,void**,int,int*,void**,int,int*) = &transition;
    double (*display)(void*) = &Display;
    
    CS2D_Step(space,rule,display);
    return 1;
}

/*********************************************/

//**************************************
// INTERFACE FUNCTIONS


// function initialize a cell using an external value
void ExtInit(int space,int row, int col, double value){
    State* s;

    s = (State *)CS2D_Get(space,row,col);
    // assign external value to the state variables
    s->s = value;
    CS2D_Init(space,row,col,NULL);
    return;
}


// Function to set a new input to a cell, from other cellular space
void SetInput(int Fspace, int Frow, int Fcol, int Tspace, int Trow, int Tcol, int input_id){
    State* s;
    State* inp;
    
    inp = (State *)malloc(sizeof(State));
    s = (State *)CS2D_Get(Fspace,Frow,Fcol);
    *inp = *s;
    CS2D_SetInput(Tspace,Trow,Tcol,(void*)inp,input_id);
}


// function to set an external value as an input to a cell
void WExtInput(int space,int row, int col, double value,int input_id){
    double* inp;

    inp = (double *)malloc(sizeof(double));
    //convert the external value to values of the state variables
    *inp = value;

    CS2D_SetInput(space,row,col,(void*)inp,input_id);

    return;
}

// function to convert the state of a cell into a double value
double Output(int space, int row, int col){
    double out;
    
    out = Display(CS2D_Get(space,row,col));
    
    return out;
}

#endif
