/***************************************************************************************************
* Author: 
*        Victorino Sanz 
*        Dpto. Informática y Automática, UNED
*        Juan del Rosal, 16
*        28040, Madrid
*        Spain
*        Email: vsanz@dia.uned.es
*
* Licensed by Victorino Sanz under the LGPL License
* Copyright © 2013, Victorino Sanz.
* 
****************************************************************************************************/

#ifndef FURNACE
#define FURNACE

#include <CellularAutomataLib.c>

/****************************************/
/* FURNACE CELLULAR AUTOMATA       */
/****************************************/

//**************************************
// Cell state
typedef struct FURState{
    double t;
}FURState;



//**************************************
// CA WRAPPER FUNCTIONS

// Function that allocates memory and sets the default state for the cells
void * FURDefaultState(){
    FURState *s;
    s = (FURState *)malloc(sizeof(FURState));
    
    s->t = 0;
    return (void *)s;
}

// constructor for the game of life CA
int FURCreate(int nrows, int ncols, int *neighborhood, size_t n1, size_t n2, int n_inputs, int wrapped_borders,int plot_animation, int plot_range,int displayDelay, const char *path,const char *name){    
    void * (*defaultState)() = &FURDefaultState;
    return CS2D_Create(nrows, ncols, neighborhood, n1, n2, n_inputs, wrapped_borders,plot_animation,plot_range,displayDelay,path,name, defaultState);
}

// Function that describes the state of initialized cells
void FURInitialState(void *cell){
    FURState *s;
    
    s = (FURState *)cell;
    s->t = 1.0;
    
    return;
}

// initializing function for the selected cell
void FURInitial(int space, int row, int col){
    void  (*initialState)(void *) = &FURInitialState;
    CS2D_Init(space, row, col, initialState);
    return;
}

//***************************************************
// RULE FUNCTION
void *furnace(void* cellstate, void** neighbors, int n_neighbors, int *neighbors_present, void** inputs, int n_inputs, int *inputs_rcv){
    double sum;
    int i;
    FURState *out;
    FURState *cs;
    FURState **ne;
    FURState **in;
    
    cs = (FURState *)cellstate;
    ne = (FURState **)neighbors;
    in = (FURState **)inputs;
    out = (FURState *)malloc(sizeof(FURState));
    
    sum = 0;
    for(i=0;i<n_neighbors;i++){
        if(neighbors_present[i]){
            sum += ne[i]->t;
        }
    }
     
    out->t = cs->t;
    if (cs->t > sum/n_neighbors)
        out->t = cs->t;
    else 
        out->t = (sum/n_neighbors);
 
    if (in != NULL)
	for (i=0;i<n_inputs;i++)
	    if (inputs_rcv[i] > 0)
		out->t = in[i]->t;
    
    return (void *)out;
}

// Function that returns the value to display in the graphical animation
double FURDisplay(void *cell){
    FURState *s;

    s = (FURState *)cell;
    return (double)s->t;
}

int FURStep(int space){
    void* (*rule)(void*,void**,int,int*,void**,int,int*) = &furnace;
    double (*display)(void*) = &FURDisplay;
    
    CS2D_Step(space,rule,display);
    return 1;
}

/*********************************************/

void FURExtInput(int space,int row, int col, double value,int input_id){
    FURState* inp;

    inp = (FURState *)malloc(sizeof(FURState));
    inp->t = value;
    CS2D_SetInput(space,row,col,(void*)inp,input_id);

    return;
}

double FUROutput(int space, int row, int col){
    FURState* s;

    s = (FURState *)CS2D_Get(space,row,col);
    return s->t;
}

void FURSetInput(int Fspace, int Frow, int Fcol, int Tspace, int Trow, int Tcol, int input_id){
    FURState* s;
    FURState* inp;
    
    inp = (FURState *)malloc(sizeof(FURState));
    s = (FURState *)CS2D_Get(Fspace,Frow,Fcol);
    *inp = *s;
    CS2D_SetInput(Tspace,Trow,Tcol,(void*)inp,input_id);
}

#endif
