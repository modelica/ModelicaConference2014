/***************************************************************************************************
* Author: 
*        Victorino Sanz 
*        Dpto. Informática y Automática, UNED
*        Juan del Rosal, 16
*        28040, Madrid
*        Spain
*        Email: vsanz@dia.uned.es
*
* Licensed by Victorino Sanz under the LGPL License
* Copyright © 2013, Victorino Sanz.
* 
****************************************************************************************************/

#ifndef GOL
#define GOL

#include <CellularAutomataLib.c>

/****************************************/
/* GAME OF LIFE CELLULAR AUTOMATA       */
/****************************************/

//**************************************
// Cell state
typedef struct GOLState{
    int v;
}GOLState;



//**************************************
// CA WRAPPER FUNCTIONS

// Function that allocates memory and sets the default state for the cells
void * GOLDefaultState(){
    GOLState *s;
    s = (GOLState *)malloc(sizeof(GOLState));
    
    s->v = 0;
    return (void *)s;
}

// constructor for the game of life CA
int GOLCreate(int nrows, int ncols, int *neighborhood, size_t n1, size_t n2, int n_inputs, int wrapped_borders,int plot_animation, int plot_range,int displayDelay, const char *path,const char *name){    
    void * (*defaultState)() = &GOLDefaultState;
    return CS2D_Create(nrows, ncols, neighborhood, n1, n2, n_inputs, wrapped_borders,plot_animation,plot_range,displayDelay,path,name, defaultState);
}

// Function that describes the state of initialized cells
void GOLInitialState(void *cell){
    GOLState *s;
    
    s = (GOLState *)cell;
    s->v = 1;
    
    return;
}

// initializing function for the selected cell
void GOLInitial(int space, int row, int col){
    void  (*initialState)(void *) = &GOLInitialState;
    CS2D_Init(space, row, col, initialState);
    return;
}

//***************************************************
// RULE FUNCTION
void *gol(void* cellstate, void** neighbors, int n_neighbors, int *neighbors_present, void** inputs, int n_inputs, int *inputs_rcv){
    int sum,i;
    GOLState *out;
    GOLState *cs;
    GOLState **ne;
    GOLState **in;
    
    cs = (GOLState *)cellstate;
    ne = (GOLState **)neighbors;
    in = (GOLState **)inputs;
    out = (GOLState *)malloc(sizeof(GOLState));
    
    sum = 0;
    //  ModelicaFormatMessage("NEIGBORS[");// cell not evaluated
    for(i=0;i<n_neighbors;i++){
        if(neighbors_present[i]){
            //      ModelicaFormatMessage("%d,%f;",i,neighbors[i]);// cell not evaluated
            sum += ne[i]->v;
        }
    }
    //     ModelicaFormatMessage("]\n");// cell not evaluated
    
    out->v = cs->v;
    if (!cs->v && sum == 3)
        out->v = 1;
    else if (cs->v && (sum < 2 || sum > 3 ) )
        out->v = 0;
    
    return (void *)out;
}

// Function that returns the value to display in the graphical animation
double GOLDisplay(void *cell){
    GOLState *s;

    s = (GOLState *)cell;
    return (double)s->v;
}

int GOLStep(int space){
    void* (*rule)(void*,void**,int,int*,void**,int,int*) = &gol;
    double (*display)(void*) = &GOLDisplay;
    
    CS2D_Step(space,rule,display);
    return 1;
}

#endif
