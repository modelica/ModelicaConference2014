Licensed by Heinz Nixdorf Institute under the Modelica License 2
Copyright � 2013-2014, Heinz Nixdorf Institute.

The use of the content of this folder is completely at your own risk; it can be redistributed and/or modified under the terms of the Modelica License 2. For license conditions (including the disclaimer of warranty) see Modelica.UsersGuide.ModelicaLicense2 or visit http://www.modelica.org/licenses/ModelicaLicense2.